﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class RandomCourse:Course
    {
        public RandomCourse()
        {
            this.Title = RandomService.Text(_titleArr, _titleArr.Length);
            this.Stream = RandomService.Text(_streamArr, _streamArr.Length);
            this.Type = new string[] { "Full Time", "Part Time"};
            this.StartDate = RandomService.SubmissionDate(1,1,10);
            this.EndDate = RandomService.SubmissionDate(3,18,28);
        }
    }
}
