﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class RandomTrainer:Trainer
    {
        public RandomTrainer()
        {
            this.FirstName = RandomService.Text(_firstNameArr, _firstNameArr.Length);
            this.LastName = RandomService.Text(_lastNameArr, _lastNameArr.Length);
            this.Subject = RandomService.Text(_subjectArr, _subjectArr.Length);
        }
    }
}
