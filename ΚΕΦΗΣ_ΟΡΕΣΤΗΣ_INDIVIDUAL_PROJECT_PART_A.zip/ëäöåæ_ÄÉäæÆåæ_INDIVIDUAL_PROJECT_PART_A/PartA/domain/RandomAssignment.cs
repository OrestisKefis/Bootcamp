﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class RandomAssignment:Assignment
    {
        public RandomAssignment()
        {
            this.Title = RandomService.Text(_tilteArr, _tilteArr.Length);
            this.Description = RandomService.Text(_desrciptionArr, _desrciptionArr.Length);
            this.SubmissionDateTime = RandomService.AssignmentSubmissionDate(1, 25, 1, 3);
            this.OralMark = RandomService.Number(10, 100);
            this.TotalMark = 100 - OralMark;
        }
    }
}
