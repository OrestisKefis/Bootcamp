﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class RandomStudent:Student
    {
        public RandomStudent()
        {
            this.FirstName = RandomService.Text(_firstNameArr, _firstNameArr.Length);
            this.LastName = RandomService.Text(_lastNameArr, _lastNameArr.Length);
            this.DateOfBirth = RandomService.Date();
            this.TuitionFees = RandomService.Number(20, 2000);
            this.AssignmentList = PerStudentService.CreateRandomList();
        }
    }
}
