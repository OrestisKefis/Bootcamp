﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class PerCourse
    {
        private Course _course;

        public Course Course
        {
            get { return _course; }
            set { _course = value; }
        }

        private List<Student> _studentList = new List<Student>();

        public List<Student> StudentList
        {
            get { return _studentList; }
            set { _studentList = value; }
        }

        private List<Trainer> _trainerList = new List<Trainer>();

        public List<Trainer> TrainerList
        {
            get { return _trainerList; }
            set { _trainerList = value; }
        }

        private List<Assignment> _assignmentList = new List<Assignment>();

        public List<Assignment> AssignmentList
        {
            get { return _assignmentList; }
            set { _assignmentList = value; }
        }

        public PerCourse() { }

        //public override string ToString()
        //{
        //    return $"Course: {{{Course}}}";
        //}
    }
}
