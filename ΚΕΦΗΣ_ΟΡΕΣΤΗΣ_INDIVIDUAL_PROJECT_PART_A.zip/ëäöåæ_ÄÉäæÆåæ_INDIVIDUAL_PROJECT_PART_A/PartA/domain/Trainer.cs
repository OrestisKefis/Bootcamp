﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class Trainer
    {
        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        private string _subject;

        public string Subject
        {
            get { return _subject; }
            set { _subject = value; }
        }

        //Synthetic Data Fields
        public static string[] _firstNameArr = new string[] { "Severus", "Minerva", "Sybill", "Alastor", "Remus", "Horace", "Rolanda", "Filius", "Albus", "Percival", "Wulfric", "Ron", "Fred", "George", "Tom", "Rubeus", "Draco", "Sirius" };

        public string[] _lastNameArr = new string[] { "Snape", "McGonagall", "Trelawney", "Moody", "Lupin", "Slughorn", "Hooch", "Flitwick", "Brian", "Dumbledore", "Riddle", "Weasley", "Hagrid", "Malfoy", "Crouch", "Lestrange", "Black"};

        public string[] _subjectArr = new string[] { "Alchemy", "Tranfiguration", "Divination", "Defense against the dark arts", "Study of runes", "Potions", "Broom stick flying", "Charms", "Light saber fighting", "Storm trooper training", "Cloning", "Use of the Force", "Pistol practice" };


        public Trainer(){}

        public Trainer(string firstName, string lastName, string subject)
        {
            this.FirstName = EvaluationService.Text(firstName, _firstNameArr, _firstNameArr.Length);
            this.LastName = EvaluationService.Text(lastName, _lastNameArr, _lastNameArr.Length);
            this.Subject = EvaluationService.Text(subject, _subjectArr, _subjectArr.Length);
        }

        public override string ToString()
        {
            return $"\tFull Name: {{{FirstName} {LastName}}} \n\tSubject: {{{Subject}}} \n";
        }
    }
}
