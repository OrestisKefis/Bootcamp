﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class Student
    {
        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        private DateTime _dateOfBirth;

        public DateTime DateOfBirth
        {
            get { return _dateOfBirth; }
            set { _dateOfBirth = value; }
        }

        private double _tuitionFees;

        public double TuitionFees
        {
            get { return _tuitionFees; }
            set { _tuitionFees = value; }
        }

        private List<Assignment> _assignmentList;

        public List<Assignment> AssignmentList
        {
            get { return _assignmentList; }
            set { _assignmentList = value; }
        }



        //Synthetic Data Fields
        public static string[] _firstNameArr = new string[] { "Orestis", "Eleni", "Kostas", "Chris", "John", "Linos", "Sklavos", "Parhs", "Alex", "Marinos", "Marios", "Sifis", "Luke", "Obi Wan", "Anakin", "Yoda", "Palpatin", "Darth", "Harry", "Jack", "Suave" };

        public string[] _lastNameArr = new string[] { "Kefis", "Tsompan", "Karagiwrgos", "Metaxopoulos", "Papazoglou", "Linopoulos", "Sklavidis", "Mixalopoulos", "Alexiou", "Tsarouxoglou", "Kenobi", "Skywalker", "Vader", "Sidius", "Maul", "Sparrow", "Potter", "Mente", "Revan" };


        public Student() { }

        public Student(string firstName, string lastName, DateTime dateOfBirth, double tuitionFees)
        {
            this.FirstName = EvaluationService.Text(firstName, _firstNameArr, _firstNameArr.Length);
            this.LastName = EvaluationService.Text(lastName, _lastNameArr, _lastNameArr.Length);
            this.DateOfBirth = dateOfBirth;
            this.TuitionFees = tuitionFees;
            this.AssignmentList = PerStudentService.CreateRandomList();
        }

        public override string ToString()
        {
            return $"\tFull Name: {{{FirstName} {LastName}}} \n\tDate of Birth: {{{DateOfBirth}}} \n\tTuitionFees: {{{TuitionFees}}} \n";
        }
    }
}
