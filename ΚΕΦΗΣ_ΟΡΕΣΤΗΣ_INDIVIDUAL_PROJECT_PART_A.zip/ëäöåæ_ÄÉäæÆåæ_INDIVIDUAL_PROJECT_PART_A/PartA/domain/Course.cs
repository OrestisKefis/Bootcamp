﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class Course
    {
        private string _title;

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _stream;

        public string Stream
        {
            get { return _stream; }
            set { _stream = value; }
        }

        private string[] _type;
                
        public string[] Type
        {
            get { return _type; }
            set { _type = value; }
        }

        private DateTime _startDate;

        public DateTime StartDate
        {
            get { return _startDate; }
            set { _startDate = value; }
        }

        private DateTime _endDate;

        public DateTime EndDate
        {
            get { return _endDate; }
            set { _endDate = value; }
        }

        public static string[] _titleArr = new string[] { "Course1", "Course2", "Course2", "Course4", "Course5", "Course6", "Course7", "Course8", "Course9", "Course10", "Course11", "Course12", "Course14", "Course15", "Course16", "Course17", "Course18", "Course19", "Course20", "Course21", "Course22", "Course23" };

        //Fun fact - WB stands for Witchcraft Bootcamp
        public static string[] _streamArr = new string[] { "WB1", "WB2", "WB3", "WB4", "WB5", "WB6", "WB7", "WB8", "WB9", "WB10", "WB11", "WB12", "WB13", "WB14", "WB15", "WB16", "WB17", "WB18", "WB19", "WB20" };

        public Course() { }

        public Course(string title, string stream)
        {
            this.Title = EvaluationService.Text(title, _titleArr, _titleArr.Length);
            this.Stream = EvaluationService.Text(stream, _streamArr, _streamArr.Length);
            this.Type = new string[] { "Full Time", "Part Time" };
            this.StartDate = RandomService.SubmissionDate(1,1,10);
            this.EndDate = RandomService.SubmissionDate(3,18,28);
        }

        public override string ToString()
        {
            return $"\tTitle: {{{Title}}} \n\tStream: {{{Stream}}} \n\tType: \t{{{Type[0]}}} \n\t\t{{{Type[1]}}} \n\tStart Date: {{{StartDate}}} \n\tEnd Date: {{{EndDate}}} \n";
        }
    }
}
