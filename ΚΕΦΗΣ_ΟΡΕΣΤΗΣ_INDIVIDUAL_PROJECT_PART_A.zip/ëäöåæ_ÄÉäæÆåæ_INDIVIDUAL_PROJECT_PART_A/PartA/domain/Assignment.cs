﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;

namespace PartA.domain
{
    class Assignment
    {
        private string _title;

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _description;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private DateTime _submissionDateTime;

        public DateTime SubmissionDateTime
        {
            get { return _submissionDateTime; }
            set { _submissionDateTime = value; }
        }

        private double _oralMark;

        public double OralMark
        {
            get { return _oralMark; }
            set { _oralMark = value; }
        }

        private double _totalMark;

        public double TotalMark
        {
            get { return _totalMark; }
            set { _totalMark = value; }
        }

        //Synthetic Data Fields
        public static string[] _tilteArr = new string[] { "Assignment 1", "Assignment 2", "Assignment 3", "Assignment 4", "Assignment 5", "Assignment 6", "Assignment 7", "Assignment 8", "Assignment 9", "Assignment 10", "Assignment 11", "Assignment 12", "Assignment 13", "Assignment 14", "Assignment 15", "Assignment 16", "Assignment 17", "Assignment 18", "Assignment 19", "Assignment 20", "Assignment 21", "Assignment 22", "Assignment 23", "Assignment 24", "Assignment 25", "Assignment 26", "Assignment 27", "Assignment 28", "Assignment 29", "Assignment 30" };

        public string[] _desrciptionArr = new string[] { "Description 1", "Description 2", "Description 3", "Description 4", "Description 5", "Description 6", "Description 7", "Description 8", "Description 9", "Description 10", "Description 11", "Description 12", "Description 13", "Description 14", "Description 15", "Description 16", "Description 17", "Description 18", "Description 19", "Description 20", "Description 21", "Description 22", "Description 23", "Description 24", "Description 25", "Description 26", "Description 27", "Description 28", "Description 29", "Description 30" };

        public Assignment() { }

        public Assignment(string title, string description, double oralMark)
        {
            this.Title = EvaluationService.Text(title, _tilteArr, _tilteArr.Length);
            this.Description = EvaluationService.Text(description, _desrciptionArr, _desrciptionArr.Length);
            this.SubmissionDateTime = RandomService.AssignmentSubmissionDate(1,25,1,3);
            this.OralMark = oralMark;
            this.TotalMark = 100 - oralMark;
        }

        public override string ToString()
        {
            return $"\tTitle: {{{Title}}} \n\tDescription: {{{Description}}} \n\tSubmission Date: {{{SubmissionDateTime}}} \n\tOral Mark: {{{OralMark}}} \n\tTotal Mark: {{{TotalMark}}} \n";
        }
    }
}
