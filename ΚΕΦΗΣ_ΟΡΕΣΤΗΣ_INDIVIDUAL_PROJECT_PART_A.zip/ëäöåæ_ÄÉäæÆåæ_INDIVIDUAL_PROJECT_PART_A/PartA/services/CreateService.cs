﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class CreateService
    {
        // Creation of new student
        public static Student NewStudent()
        {
            Console.Write("Give student first name: ");
            string name = Console.ReadLine();

            Console.Write("Give student last name: ");
            string lastName = Console.ReadLine();

            Console.Write("Give student date of birth: ");
            DateTime dateOfBirth = EvaluationService.Date(1980, 2002);

            Console.Write("Give student tuition fees: ");
            double tuitionFees = EvaluationService.Number(Console.ReadLine(), 40, 2501);

            Student newStudent = new Student(name, lastName, dateOfBirth, tuitionFees);
            return newStudent;
        }

        // Creation of new trainer
        public static Trainer NewTrainer()
        {
            Console.Write("Give trainer first name: ");
            string firstName = Console.ReadLine();

            Console.Write("Give trainer last name: ");
            string lastName = Console.ReadLine();

            Console.Write("Give trainer subject: ");
            string subject = Console.ReadLine();

            Trainer newTrainer = new Trainer(firstName, lastName, subject);
            return newTrainer;
        }

        // Creation of new assignment
        public static Assignment NewAssignment()
        {
            Console.Write("Give assignment title: ");
            string title = Console.ReadLine();

            Console.Write("Tell us a little something about the assignment: ");
            string description = Console.ReadLine();

            Console.Write("Give assignment oral mark: ");
            double oralMark = EvaluationService.Number(Console.ReadLine(), 10, 101);

            Assignment newAssignment = new Assignment(title, description, oralMark);
            return newAssignment;
        }

        //Creation of new course
        public static Course NewCourse()
        {
            Console.Write("Give course title: ");
            string title = Console.ReadLine();

            Console.Write("Give course stream: ");
            string stream = Console.ReadLine();

            Course newCourse = new Course(title, stream);
            return newCourse;
        }

        //Creation of new date
        public static DateTime NewDateTime()
        {
            Console.Write("\ndate: ");
            int date = int.Parse(Console.ReadLine());

            Console.Write("month: ");
            int month = int.Parse(Console.ReadLine());

            Console.Write("year: ");
            int year = int.Parse(Console.ReadLine());

            DateTime dateTime = new DateTime(year, month, date);
            return dateTime;
        }
    }
}
