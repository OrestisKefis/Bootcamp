﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class EvaluationService
    {
        // Evaluate given data and create synthetic data if input was invalid
        //String evaluation
        public static string Text(string value, string[] arr, int index)
        {
            if (ContainsOnlyLetters(value) && value.Length > 3)
            {
                return value;
            }
            value = arr[index - 1];
            return value;
        }

        private static bool ContainsOnlyLetters(string value)
        {
            bool isLetter = true;
            foreach (char c in value)
            {
                if (!Char.IsLetter(c))
                {
                    isLetter = false;
                }
                isLetter = true;
            }
            return isLetter;
        }

        // Number evalutaion
        public static double Number(string input, int minNum, int maxNum)
        {
            double num = 0;
            if (isNumber(input))
            {
                num = double.Parse(input);
            }
            num = RandomService.Number(minNum, maxNum);
            return num;
        }

        private static bool isNumber(string value)
        {
            double number = 0;
            bool isNumber = double.TryParse(value, out number);
            return isNumber;
        }

        // Date evaluation
        public static DateTime Date(int minYear, int maxYear)
        {
            DateTime dateTime = new DateTime();
            try
            {
                Console.Write("\ndate: ");
                int date = int.Parse(Console.ReadLine());

                Console.Write("month: ");
                int month = int.Parse(Console.ReadLine());

                Console.Write("year: ");
                int year = int.Parse(Console.ReadLine());

                dateTime = new DateTime(year, month, date);
            }
            catch (Exception e)
            {
                dateTime = RandomService.Date();
            }

            return dateTime;
        }

        public static void StillSubmitting(PerCourse perCourse)
        {
            DateTime userDateTime = new DateTime();
            bool stillTrying = true;
            while (stillTrying)
            {
                Console.WriteLine("Select a date (Should be in year 2022): ");
                try
                {
                    Console.Write("Date: ");
                    int date = int.Parse(Console.ReadLine());

                    Console.Write("Month: ");
                    int month = int.Parse(Console.ReadLine());

                    Console.Write("Year: ");
                    int year = int.Parse(Console.ReadLine());

                    userDateTime = new DateTime(year, month, date);
                    stillTrying = false;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Some imputs were wrong. Try again..");
                }
            }


            DateTime startWeekDate = new DateTime();
            DateTime endWeekDate = new DateTime();



            DayOfWeek userDayOfWeek = userDateTime.DayOfWeek;

            switch (userDayOfWeek)
            {
                case DayOfWeek.Monday:
                    startWeekDate = userDateTime;
                    endWeekDate = userDateTime.AddDays(4);
                    break;
                case DayOfWeek.Tuesday:
                    startWeekDate = userDateTime.AddDays(-1);
                    endWeekDate = userDateTime.AddDays(3);
                    break;
                case DayOfWeek.Wednesday:
                    startWeekDate = userDateTime.AddDays(-2);
                    endWeekDate = userDateTime.AddDays(2);
                    break;
                case DayOfWeek.Thursday:
                    startWeekDate = userDateTime.AddDays(-3);
                    endWeekDate = userDateTime.AddDays(1);
                    break;
                case DayOfWeek.Friday:
                    startWeekDate = userDateTime.AddDays(-4);
                    endWeekDate = userDateTime;
                    break;
                case DayOfWeek.Saturday:
                    startWeekDate = userDateTime.AddDays(-5);
                    endWeekDate = userDateTime.AddDays(-1);
                    break;
                case DayOfWeek.Sunday:
                    startWeekDate = userDateTime.AddDays(-6);
                    endWeekDate = userDateTime.AddDays(-2);
                    break;
                default:
                    Console.WriteLine("Not a day of the week");
                    break;

            };

            //Testing
            //Console.WriteLine($"UserDate: {userDateTime} Day: {userDateTime.DayOfWeek}");
            //Console.WriteLine($"Start: {startWeekDate} Day: {startWeekDate.DayOfWeek}");
            //Console.WriteLine($"End: {endWeekDate} Day: {endWeekDate.DayOfWeek}");


            List<Student> studentsWhoStillSubmit = new List<Student>();
            foreach (Student student in perCourse.StudentList)
            {
                foreach (Assignment assignment in student.AssignmentList)
                {
                    DateTime submissionDate = assignment.SubmissionDateTime;
                    if (submissionDate >= startWeekDate && endWeekDate >= submissionDate)
                    {
                        if (!studentsWhoStillSubmit.Contains(student))
                        {
                            studentsWhoStillSubmit.Add(student);
                        }
                    }
                }
            }

            //Console.WriteLine($"Students who still submit count: {studentsWhoStillSubmit.Count}");
            foreach (Student student in studentsWhoStillSubmit)
            {
                Console.WriteLine(student);
                Console.WriteLine("-----------------------------------");
            }
        }

        //List evaluation
        public static void StudentCount(PrivateSchool privateSchool, List<Student> studentList)
        {
            if (studentList.Count == 0)
            {
                Console.Write("Student list is empty. Press any key to add data now..");
                Console.ReadLine();
                NewApplicationService.Student(privateSchool);
            }
            else
            {
                PrintService.PrintStudent(privateSchool);
            }
        }

        public static void TrainerCount(PrivateSchool privateSchool, List<Trainer> trainerList)
        {
            if (trainerList.Count == 0)
            {
                Console.Write("Trainer list is empty. Press any key to add data now..");
                Console.ReadLine();
                NewApplicationService.Trainer(privateSchool);
            }
            else
            {
                PrintService.PrintTrainer(privateSchool);
            }
        }

        public static void CourseCount(PrivateSchool privateSchool, List<Course> courseList)
        {
            if (courseList.Count == 0)
            {
                Console.Write("Course list is empty. Press any key to add data now..");
                Console.ReadLine();
                NewApplicationService.Course(privateSchool);
            }
            else
            {
                PrintService.PrintCourse(privateSchool);
            }
        }

        public static void AssignmentCount(PrivateSchool privateSchool, List<Assignment> assignmentList)
        {
            if (assignmentList.Count == 0)
            {
                Console.Write("Assignment list is empty. Press any key to add data now..");
                Console.ReadLine();
                NewApplicationService.Assignment(privateSchool);
            }
            else
            {
                PrintService.PrintAssignment(privateSchool);
            }
        }

        public static void AllListCount(PrivateSchool privateSchool, List<Student> students, List<Trainer> trainers, List<Course> courses, List<Assignment> assignments)
        {
            if (students.Count == 0 || trainers.Count == 0 || courses.Count == 0 || assignments.Count == 0)
            {
                Console.Write("You need to fill all the lists before associating data per course. Press any key to add data now..");
                Console.ReadLine();

                if (students.Count == 0)
                {
                    NewApplicationService.Student(privateSchool);
                }
                else if (trainers.Count == 0)
                {
                    NewApplicationService.Trainer(privateSchool);
                }
                else if (courses.Count == 0)
                {
                    NewApplicationService.Course(privateSchool);
                }
                else if (assignments.Count == 0)
                {
                    NewApplicationService.Assignment(privateSchool);
                }
            }
            else
            {
                PrintService.PrintCourse(privateSchool);
                PrivateSchool.PerCourseAssociation(privateSchool, students, trainers, courses, assignments);
                Process.GetCurrentProcess().Kill();
            }
        }
    }
}
