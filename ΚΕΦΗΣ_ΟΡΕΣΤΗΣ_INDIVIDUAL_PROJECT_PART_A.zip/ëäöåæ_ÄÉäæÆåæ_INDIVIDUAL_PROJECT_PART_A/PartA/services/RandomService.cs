﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class RandomService
    {
        private static List<string> _textList = new List<string>();
        private static Random _rand = new Random();
        // Date
        public static DateTime Date()
        {
            int year = _rand.Next(1980, 2004);
            int month = _rand.Next(1, 12);
            int date = _rand.Next(1, 29);
            DateTime dateTime = new DateTime(year, month, date);
            return dateTime;
        }

        public static DateTime SubmissionDate(int month, int minDate, int maxDate)
        {
            int year = 2022;
            int date = _rand.Next(minDate, maxDate); //1,28
            DateTime dateTime = new DateTime(year, month, date);
            return dateTime;
        }

        public static DateTime AssignmentSubmissionDate(int minDate, int maxDate, int minMonth, int maxMonth)
        {
            int year = 2022;
            int date = _rand.Next(minDate, maxDate);
            int month = _rand.Next(minMonth, maxMonth);
            DateTime dateTime = new DateTime(year, month, date);
            return dateTime;
        }

        //Numeric
        public static double Number(int minNum, int maxNum)
        {
            double number = _rand.Next(minNum, maxNum);
            return number;
        }

        public static int Index(int maxIndex)
        {
            int index = _rand.Next(maxIndex);
            return index;
        }

        //String
        public static string Text(string[] arr, int index)
        {
            string text = arr[_rand.Next(index)];
            if (!_textList.Contains(text))
            {
                _textList.Add(text);
            }
            else
            {
                while (_textList.Contains(text))
                {
                    text = arr[_rand.Next(index)];
                }
            }
            return text;
        }
    }
}
