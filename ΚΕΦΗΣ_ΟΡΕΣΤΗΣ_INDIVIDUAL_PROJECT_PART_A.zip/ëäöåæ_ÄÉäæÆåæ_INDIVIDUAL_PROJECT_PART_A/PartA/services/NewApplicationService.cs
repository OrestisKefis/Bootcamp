﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class NewApplicationService:PrivateSchool
    {
        // Student application
        public static void Student(PrivateSchool privateSchool)
        {
            Console.WriteLine("Add new student: ");
            string yesOrNo = "";
            bool addAnotherStudent = true;
            while (addAnotherStudent)
            {
                privateSchool.AddNewStudent();
                Console.Write("Would you like to add another student? (Y/N)");
                yesOrNo = Console.ReadLine().ToUpper();
                Student randomStudent = new RandomStudent();
                if (yesOrNo != "Y")
                {
                    while (privateSchool.StudentList.Count < 10)
                    {
                        if (privateSchool.StudentList.Contains(randomStudent))
                        {
                            randomStudent = new RandomStudent();
                        }
                        else
                        {
                            privateSchool.StudentList.Add(randomStudent);
                        }
                    }
                    addAnotherStudent = false;
                }
            }
        }

        // Trainer application
        public static void Trainer(PrivateSchool privateSchool)
        {
            Console.WriteLine("Add new trainer: ");
            string yesOrNo = "";
            bool addAnotherTrainer = true;
            while (addAnotherTrainer)
            {
                privateSchool.AddNewTrainer();
                Console.Write("Would you like to add another trainer? (Y/N)");
                yesOrNo = Console.ReadLine().ToUpper();
                Trainer randomTrainer = new RandomTrainer();
                if (yesOrNo != "Y")
                {
                    while (privateSchool.TrainerList.Count < 8)
                    {
                        if (privateSchool.TrainerList.Contains(randomTrainer))
                        {
                            randomTrainer = new RandomTrainer();
                        }
                        else
                        {
                            privateSchool.TrainerList.Add(randomTrainer);
                        }
                    }
                    addAnotherTrainer = false;
                }
            }
        }

        // Assignment application
        public static void Assignment(PrivateSchool privateSchool)
        {
            Console.WriteLine("Add new assignment: ");
            string yesOrNo = "";
            bool addAnotherAssignment = true;
            while (addAnotherAssignment)
            {
                privateSchool.AddNewAssignment();
                Console.Write("Would you like to add another assignment? (Y/N)");
                yesOrNo = Console.ReadLine().ToUpper();
                Assignment randomAssignment = new RandomAssignment();
                if (yesOrNo != "Y")
                {
                    while (privateSchool.AssignmentList.Count < 7)
                    {
                        if (privateSchool.AssignmentList.Contains(randomAssignment))
                        {
                            randomAssignment = new RandomAssignment();
                        }
                        else
                        {
                            privateSchool.AssignmentList.Add(randomAssignment);
                        }
                    }
                    addAnotherAssignment = false;
                }
            }
        }

        // Course application
        public static void Course(PrivateSchool privateSchool)
        {
            Console.WriteLine("Add new course: ");
            string yesOrNo = "";
            bool addAnotherCourse = true;
            while (addAnotherCourse)
            {
                privateSchool.AddNewCourse();
                Console.Write("Would you like to add another course? (Y/N)");
                yesOrNo = Console.ReadLine().ToUpper();
                Course randomCourse = new RandomCourse();
                if (yesOrNo != "Y")
                {
                    while (privateSchool.CourseList.Count < 7)
                    {
                        if (privateSchool.CourseList.Contains(randomCourse))
                        {
                           randomCourse = new RandomCourse();
                        }
                        else
                        {
                            privateSchool.CourseList.Add(randomCourse);
                        }
                    }
                    addAnotherCourse = false;
                }
            }
        }
    }
}
