﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class PrivateSchool
    {
        private List<Student> _studentList = new List<Student>();
        public List<Student> StudentList 
        {
            get
            {
                return _studentList;
            }
            set
            {
                _studentList = value;
            }
        }

        private List<Trainer> _trainerList = new List<Trainer>();

        public List<Trainer> TrainerList
        {
            get 
            { 
                return _trainerList; 
            }
        }

        private List<Assignment> _assignmentList = new List<Assignment>();

        public List<Assignment> AssignmentList
        {
            get 
            { 
                return _assignmentList;
            }
        }

        private List<Course> _courseList = new List<Course>();

        public List<Course> CourseList
        {
            get { return _courseList; }
            set { _courseList = value; }
        }

        private List<PerCourse> _perCourseList = new List<PerCourse>();

        public List<PerCourse> PerCourseList
        {
            get { return _perCourseList; }
            set { _perCourseList = value; }
        }


        // Add user created objects into a list
        public List<Student> AddNewStudent()
        {
            _studentList.Add(CreateService.NewStudent());
            return _studentList;
        }

        public List<Trainer> AddNewTrainer()
        {
            _trainerList.Add(CreateService.NewTrainer());
            return _trainerList;
        }

        public List<Assignment> AddNewAssignment()
        {
            _assignmentList.Add(CreateService.NewAssignment());
            return _assignmentList;
        }

        public List<Course> AddNewCourse()
        {
            _courseList.Add(CreateService.NewCourse());
            return _courseList;
        }


        //Make new applications based on either user input data or synthetic data
        public static void NewApplications(PrivateSchool privateSchool)
        {
            bool keepAdding = true;
            while (keepAdding)
            {
                Console.WriteLine("CHOOSE TO ADD (SYNTHETIC DATA WILL BE PRODUCED IN CASE OBJECTS ARE BLANK): \n\tNEW STUDENT (S) \n\tNEW TRAINER (T) \n\tNEW COURSE (C) \n\tNEW ASSIGNMENT (A)");

                Console.WriteLine("\n\tEXIT THE PROGRAM: 'E'");
                string userChoice1 = Console.ReadLine().ToUpper();
                switch (userChoice1)
                {
                    case "S":
                        NewApplicationService.Student(privateSchool);
                        break;
                    case "T":
                        NewApplicationService.Trainer(privateSchool);
                        break;
                    case "C":
                        NewApplicationService.Course(privateSchool);
                        break;
                    case "A":
                        NewApplicationService.Assignment(privateSchool);
                        break;
                    case "E":
                        Process.GetCurrentProcess().Kill();
                        break;
                    default:
                        Console.WriteLine("Wrong input...");
                        break;
                }

                Console.WriteLine("Would you like to make a different application? (Y/N)");
                string userChoice2 = Console.ReadLine().ToUpper();
                if (userChoice2 != "Y")
                {
                    keepAdding = false;
                }
            }
            
        }

        //Starting method
        public static void Start(PrivateSchool privateSchool)
        {
            //string startChoice = Console.ReadLine();
            bool stayOnMainMenu = true;
            while (stayOnMainMenu)
            {
                Console.WriteLine("SELECT HOW YOU WANT TO PROCEED: \n\t1.MAKE NEW APPLICATION \n\t2.PRINT DATA \n\t3.EXIT");
                string startChoice = Console.ReadLine();
                int students = privateSchool.StudentList.Count;
                int trainers = privateSchool.TrainerList.Count;
                int courses = privateSchool.CourseList.Count;
                int assignments = privateSchool.AssignmentList.Count;

                if (startChoice == "1")
                {
                    NewApplications(privateSchool);
                }

                else if (startChoice == "2")
                {
                    if (students == 0 && trainers == 0 && courses == 0 && assignments == 0)
                    {
                        Console.WriteLine("No data has been added so far. Unable to print!! \nPress any key to add new applications....");
                        Console.ReadLine();
                        NewApplications(privateSchool);
                    }
                    else
                    {
                        PrintChosenList(privateSchool);
                        stayOnMainMenu = false;
                    }
                }
                else if (startChoice == "3")
                {
                    Process.GetCurrentProcess().Kill();
                }
            }
        }

        //Evaluate list count and print it after valid evalutaion
        public static void PrintChosenList(PrivateSchool privateSchool)
        {
            Console.Write("WHAT WOULD YOU LIKE TO PRINT? \n\t1.STUDENTS \n\t2.TRAINERS \n\t3.COURSES \n\t4.ASSIGNMENTS \n\t5.DATA PER COURSE");

            Console.WriteLine("\n\t6.EXIT THE PROGRAM");

            List<Student> students = privateSchool.StudentList;
            List<Trainer> trainers = privateSchool.TrainerList;
            List<Course> courses = privateSchool.CourseList;
            List<Assignment> assignments = privateSchool.AssignmentList;

            bool keepPrinting = true;
            while (keepPrinting)
            {
                string printChoice = Console.ReadLine();
                if (printChoice == "1")
                {
                    EvaluationService.StudentCount(privateSchool, students);
                }
                else if (printChoice == "2")
                {
                    EvaluationService.TrainerCount(privateSchool, trainers);
                }
                else if (printChoice == "3")
                {
                    EvaluationService.CourseCount(privateSchool, courses);
                }
                else if (printChoice == "4")
                {
                    EvaluationService.AssignmentCount(privateSchool, assignments);
                }
                else if (printChoice == "5")
                {
                    EvaluationService.AllListCount(privateSchool, students, trainers, courses, assignments);
                }
                else if (printChoice == "6")
                {
                    Process.GetCurrentProcess().Kill();
                }

                Console.WriteLine("Would you like to print anything else? (Y/N)");
                string yesOrNo = Console.ReadLine().ToUpper();
                switch (yesOrNo)
                {
                    case "Y":
                        PrintChosenList(privateSchool);
                        keepPrinting = true;
                        break;
                    default:
                        keepPrinting = false;
                        break;
                }
                
            }
        }

        //Associate filled list data to each other
        public static void PerCourseAssociation(PrivateSchool privateSchool, List<Student> studentList, List<Trainer> trainerList, List<Course> courseList, List<Assignment> assignmentList)
        {
            //Associate objects with a selected course
            PerCourseService.MainAssociationProcedure(privateSchool, studentList, trainerList, courseList, assignmentList);

            //Repeat the association procedure for a different course
            PerCourseService.DifferentCourseAssociation(privateSchool, studentList, trainerList, courseList, assignmentList);
        }
    }
}
