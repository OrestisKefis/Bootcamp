﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class PerStudentService
    {
        //Create and fill list
        public static List<Assignment> CreateRandomList()
        {
            List<Assignment> randomAssignmentList = new List<Assignment>();
            while (randomAssignmentList.Count < 3)
            {
                randomAssignmentList.Add(new RandomAssignment());
            }
            return randomAssignmentList;
        }
    }
}
