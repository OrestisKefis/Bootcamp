﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class PrintService
    {
        //Students
        public static void PrintStudent(PrivateSchool privateSchool)
        {
            foreach (Student student in privateSchool.StudentList)
            {
                Console.WriteLine(student);
            }
        }

        //Trainer
        public static void PrintTrainer(PrivateSchool privateSchool)
        {
            foreach (Trainer trainer in privateSchool.TrainerList)
            {
                Console.WriteLine(trainer);
            }
        }

        //Assignment
        public static void PrintAssignment(PrivateSchool privateSchool)
        {
            foreach (Assignment assignment in privateSchool.AssignmentList)
            {
                Console.WriteLine(assignment);
            }
        }

        //Course
        public static void PrintCourse(PrivateSchool privateSchool)
        {
            foreach(Course course in privateSchool.CourseList)
            {
                Console.WriteLine(course);
            }
        }

        //Student(s) per course
        public static void PrintStudentPerCourse(PerCourse perCourse)
        {
            foreach (Student student in perCourse.StudentList)
            {
                Console.WriteLine(student);
            }

        }

        //Trainer(s) per course
        public static void PrintTrainerPerCourse(PerCourse perCourse)
        {
            foreach (Trainer trainer in perCourse.TrainerList)
            {
                Console.WriteLine(trainer);
            }
        }

        //Assignment(s) per course
        public static void PrintAssignmentPerCourse(PerCourse perCourse)
        {
            foreach (Assignment assignment in perCourse.AssignmentList)
            {
                Console.WriteLine(assignment);
            }
        }
    }
}
