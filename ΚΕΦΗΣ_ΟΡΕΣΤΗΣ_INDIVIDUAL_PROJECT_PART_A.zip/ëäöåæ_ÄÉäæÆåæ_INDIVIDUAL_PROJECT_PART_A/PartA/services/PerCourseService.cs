﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.domain;

namespace PartA.services
{
    class PerCourseService:PerCourse
    {
        //Main association per course procedure
        public static void MainAssociationProcedure(PrivateSchool privateSchool, List<Student> studentList, List<Trainer> trainerList, List<Course> courseList, List<Assignment> assignmentList)
        {
            PerCourse perCourse = new PerCourse();
            privateSchool.PerCourseList.Add(perCourse);

            bool chooseCourse = true;
            while (chooseCourse)
            {
                Console.Write("Pick a course by title: ");
                try
                {
                    string userCourseChoice = Console.ReadLine();
                    perCourse.Course = courseList.First(course => course.Title == userCourseChoice);
                    chooseCourse = false;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Course does not exist. Pick again...");
                }
            }

            bool choosePerCourse = true;
            while (choosePerCourse)
            {
                Console.WriteLine("NEW ADDITION PER COURSE: \n\t1.ADD STUDENT PER COURSE \n\t2.ADD TRAINER PER COURSE \n\t3.ADD ASSIGNMENT PER COURSE");

                Console.WriteLine("PRINT DATA: \n\t4.STUDENT(S) PER COURSE LIST \n\t5.TRAINER(S) PER COURSE LIST \n\t6.ASSIGNMENT(S) PER COURSE LIST  \n\t7.ASSIGNMENT(S) PER COURSE PER STUDENT \n\t8.STUDENT LIST \n\t9.TRAINER LIST \n\t10.ASSIGNMENT LIST \n\t11.STUDENTS WHO BELONG IN MORE THAN ONE COURSE \n\t12.STUDENTS WHO OWE ASSIGNMENTS");

                Console.WriteLine("\n\t6.EXIT THE PROGRAM");

                string userChoice = Console.ReadLine().ToUpper();
                switch (userChoice)
                {
                    case "1":
                        PrintService.PrintStudent(privateSchool);
                        RepeatAssociateStudent(studentList, perCourse);
                        break;
                    case "2":
                        PrintService.PrintTrainer(privateSchool);
                        RepeatAssociateTrainer(trainerList, perCourse);
                        break;
                    case "3":
                        PrintService.PrintAssignment(privateSchool);
                        RepeatAssociateAssignment(assignmentList, perCourse);
                        break;
                    case "4":
                        if (perCourse.StudentList.Count != 0)
                            PrintService.PrintStudentPerCourse(perCourse);
                        else
                            Console.WriteLine("Student list per course is empty");
                        break;
                    case "5":
                        if (perCourse.TrainerList.Count != 0)
                            PrintService.PrintTrainerPerCourse(perCourse);
                        else
                            Console.WriteLine("Trainer list per course is empty");
                        break;
                    case "6":
                        if (perCourse.AssignmentList.Count != 0)
                            PrintService.PrintAssignmentPerCourse(perCourse);
                        else
                            Console.WriteLine("Assignment list per course is empty");
                        break;
                    case "7":
                        if (perCourse.StudentList.Count == 0)
                        {
                            Console.WriteLine("Student list per course is empty");
                        }
                        else
                        {
                            foreach (Student student in perCourse.StudentList)
                            {
                                Console.WriteLine(student);
                                foreach (Assignment assignment in student.AssignmentList)
                                {
                                    Console.WriteLine(assignment);
                                }
                                Console.WriteLine("---------------------------------");
                            }
                        }
                        break;
                    case "8":
                        PrintService.PrintStudent(privateSchool);
                        break;
                    case "9":
                        PrintService.PrintTrainer(privateSchool);
                        break;
                    case "10":
                        PrintService.PrintAssignment(privateSchool);
                        break;
                    case "11":
                        if(privateSchool.PerCourseList.Count <= 1)
                            Console.WriteLine("No students belong to more than two courses");
                        else
                            StudentsInMoreThanOneCourses(privateSchool);
                        break;
                    case "12":
                        if (perCourse.StudentList.Count == 0)
                            Console.WriteLine("Student list per course is still empty");
                        else
                            EvaluationService.StillSubmitting(perCourse);
                        break;
                    default:
                        Console.WriteLine("Wrong input...");
                        break;
                }

                Console.WriteLine("Would you like to add/print anything else? (Y/N)");
                string associateMore = Console.ReadLine().ToUpper();
                switch (associateMore)
                {
                    case "Y":
                        break;
                    default:
                        choosePerCourse = false;
                        break;
                }
            }
        }

        //Add different course to associate objects with
        public static void DifferentCourseAssociation(PrivateSchool privateSchool, List<Student> studentList, List<Trainer> trainerList, List<Course> courseList, List<Assignment> assignmentList)
        {
            bool associateWithDifferentCourse = true;
            while (associateWithDifferentCourse)
            {
                Console.WriteLine("Would you like to associate objects with a different course? (Y/N)");
                string yerOrNo = Console.ReadLine().ToUpper();
                switch (yerOrNo)
                {
                    case "Y":
                        PrintService.PrintCourse(privateSchool);
                        PrivateSchool.PerCourseAssociation(privateSchool, studentList, trainerList, courseList, assignmentList);
                        associateWithDifferentCourse = false;
                        break;
                    default:
                        associateWithDifferentCourse = false;
                        break;
                }
            }
        }

        //Add students found in more than one course to a list
        private static void StudentsInMoreThanOneCourses(PrivateSchool privateSchool)
        {
            List<Student> sameStudents = new List<Student>();
            List<Student> diffStudents = new List<Student>();

            foreach (PerCourse course in privateSchool.PerCourseList)
            {
                foreach (Student student in course.StudentList)
                {
                    if (diffStudents.Contains(student))
                    {
                        sameStudents.Add(student);
                    }
                    else
                    {
                        diffStudents.Add(student);
                    }
                }
            }

            foreach (Student student in sameStudents)
            {
                Console.WriteLine(student);
            }
        }

        //Associate object per course
        private static void AssociateStudent(List<Student> studentList, PerCourse perCourse)
        {
            Console.Write("Select student by first name: ");
            try
            {
                string userStudentChoice = Console.ReadLine();
                var pickedStudent = studentList.First(student => student.FirstName == userStudentChoice);
                perCourse.StudentList.Add(pickedStudent);
            }
            catch (Exception e)
            {
                Console.WriteLine("Student does not exist. Pick again..");
                AssociateStudent(studentList, perCourse);
            }
        }

        private static void AssociateTrainer(List<Trainer> trainerList, PerCourse perCourse)
        {
            Console.Write("Select trainer by first name: ");
            try
            {
                string userTrainerChoice = Console.ReadLine();
                var pickedTrainer = trainerList.First(trainer => trainer.FirstName == userTrainerChoice);
                perCourse.TrainerList.Add(pickedTrainer);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trainer does not exist. Pick again..");
                AssociateTrainer(trainerList, perCourse);
            }
        }

        private static void AssociateAssignment(List<Assignment> assignmentList, PerCourse perCourse)
        {
            Console.Write("Select assignment by title: ");
            try
            {
                string userAssignmentChoice = Console.ReadLine();
                var pickedAssignment = assignmentList.First(assignment => assignment.Title == userAssignmentChoice);
                perCourse.AssignmentList.Add(pickedAssignment);
            }
            catch (Exception e)
            {
                Console.WriteLine("Assignment does not exist.Pick again..");
                AssociateAssignment(assignmentList, perCourse);
            }
        }


        //Repeat associate object methods for as long as the user requires
        private static void RepeatAssociateStudent(List<Student> studentList, PerCourse perCourse)
        {
            AssociateStudent(studentList, perCourse);
            bool addMoreStudents = true;
            while (addMoreStudents)
            {
                Console.WriteLine("Would you like to associate another student with the course? (Y/N)");
                string yesOrNo = Console.ReadLine().ToUpper();
                switch (yesOrNo)
                {
                    case "Y":
                        AssociateStudent(studentList, perCourse);
                        break;
                    default:
                        addMoreStudents = false;
                        break;
                }
            }
        }

        private static void RepeatAssociateTrainer(List<Trainer> trainerList, PerCourse perCourse)
        {
            AssociateTrainer(trainerList, perCourse);
            bool addMoreTrainers = true;
            while (addMoreTrainers)
            {
                Console.WriteLine("Would you like to associate another trainer with the course? (Y/N)");
                string yesOrNo = Console.ReadLine().ToUpper();
                switch (yesOrNo)
                {
                    case "Y":
                        AssociateTrainer(trainerList, perCourse);
                        break;
                    default:
                        addMoreTrainers = false;
                        break;
                }
            }
        }

        private static void RepeatAssociateAssignment(List<Assignment> assignmentList, PerCourse perCourse)
        {
            AssociateAssignment(assignmentList, perCourse);
            bool addMoreAssignments = true;
            while (addMoreAssignments)
            {
                Console.WriteLine("Would you like to associate another assignment with the course? (Y/N)");
                string yesOrNo = Console.ReadLine().ToUpper();
                switch (yesOrNo)
                {
                    case "Y":
                        AssociateAssignment(assignmentList, perCourse);
                        break;
                    default:
                        addMoreAssignments = false;
                        break;
                }
            }
        }
    }
}
