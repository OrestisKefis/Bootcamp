﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PartA.services;
using PartA.domain;

namespace PartA
{
    class Program
    {
        static void Main(string[] args)
        {
            //Starting point

            PrivateSchool privateSchool = new PrivateSchool();
            PrivateSchool.Start(privateSchool);
        }
    }
}
